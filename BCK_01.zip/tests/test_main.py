
def test_main_ok():
    assert 1 == 1
