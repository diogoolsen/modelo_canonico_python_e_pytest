# from package_01 import *  # noqa: F401
# from package_01.module_p1_01 import p1_m1  # noqa: F401

#
# IMPORT
#
# import <PACKAGE>
#
# o import só aceita pacotes e módulos
# - Não podem ser submodulos, subpacotes ou
# outros nomes definidos no pacote\modulo

# Dá erro pois está tentando importar um nome no módulo
# import package_01.package_01_a.module_p1a_01.p1_p1a_m1

# OK!
# from . import package_01
#

import package_A.package_B.module_p1a_01.p1_p1a_m1
import package_A
import package_C


print('->', package_A.module_p1_01.p1_m1)
print('->', package_A.module_p1_02.p1_m2)

print('->', package_A.package_B.module_p1a_01.p1_p1a_m1)
print('->', package_A.package_B.module_p1a_02.p1_p1a_m2)

print('->', package_C.module_p2_01.p2_m1)
print('->', package_C.module_p2_02.p2_m2)
